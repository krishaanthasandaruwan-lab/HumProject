// Shared AudioContext + master bus. The context is created/resumed inside a tap (iOS rule).
type SessionType = 'auto' | 'playback' | 'play-and-record' | 'ambient';

let ctx: AudioContext | undefined;
let master: GainNode | undefined;
let limiter: DynamicsCompressorNode | undefined;
let streamDest: MediaStreamAudioDestinationNode | undefined;

export const MASTER_GAIN = 0.85;

/** Gentle bus limiter shared by live playback and offline renders. */
export function makeLimiter(c: BaseAudioContext): DynamicsCompressorNode {
  const l = c.createDynamicsCompressor();
  l.threshold.value = -8;
  l.knee.value = 4;
  l.ratio.value = 12;
  l.attack.value = 0.002;
  l.release.value = 0.12;
  return l;
}

export function isIOS(): boolean {
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}

export function getCtx(): AudioContext {
  if (!ctx || ctx.state === 'closed') {
    streamDest = undefined;
    const Ctor =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const opts: AudioContextOptions = { latencyHint: 'interactive' };
    if (isIOS()) opts.sampleRate = 48000; // iOS mic runs at 48 kHz; mismatches cause silence
    try {
      ctx = new Ctor(opts);
    } catch {
      ctx = new Ctor();
    }
    master = ctx.createGain();
    master.gain.value = MASTER_GAIN;
    limiter = makeLimiter(ctx);
    master.connect(limiter).connect(ctx.destination);
  }
  return ctx;
}

/** A failed capture can leave Safari's context interrupted even after resume(). */
export function resetAudioContext(): void {
  const old = ctx;
  ctx = undefined;
  master = undefined;
  limiter = undefined;
  streamDest = undefined;
  if (old && old.state !== 'closed') void old.close().catch(() => undefined);
}

/** Everything audible goes through here (then a limiter, then the speakers). */
export function getMaster(): GainNode {
  getCtx();
  return master as GainNode;
}

/** Master output as a MediaStream — used to record video with sound. */
export function getStreamDest(): MediaStreamAudioDestinationNode {
  const c = getCtx();
  if (!streamDest) {
    streamDest = c.createMediaStreamDestination();
    (limiter as DynamicsCompressorNode).connect(streamDest);
  }
  return streamDest;
}

/** A mono AudioBuffer holding `data`; usable in any context (offline renders included). */
export function monoBuffer(data: Float32Array, sampleRate: number): AudioBuffer {
  const length = Math.max(1, data.length);
  let b: AudioBuffer;
  try {
    b = new AudioBuffer({ length, sampleRate, numberOfChannels: 1 });
  } catch {
    b = getCtx().createBuffer(1, length, sampleRate); // older Safari
  }
  b.getChannelData(0).set(data.subarray(0, length));
  return b;
}

/** Output-side latency the browser reports (seconds). */
export function outputLatency(): number {
  const c = getCtx();
  return (c.outputLatency || 0) + (c.baseLatency || 0);
}

/** Safari 16.4+ Audio Session API: switch between recording and loud playback routing. */
export function setAudioSession(type: SessionType): void {
  const nav = navigator as Navigator & { audioSession?: { type: string } };
  if (nav.audioSession) {
    try {
      nav.audioSession.type = type;
    } catch {
      /* unsupported value */
    }
  }
}

export async function unlockAudio(): Promise<AudioContext> {
  const c = getCtx();
  const resumed = c.state === 'running' ? Promise.resolve() : c.resume();
  // A silent buffer finishes the unlock on older iOS versions.
  const b = c.createBuffer(1, 1, c.sampleRate);
  const s = c.createBufferSource();
  s.buffer = b;
  s.connect(c.destination);
  s.onended = () => s.disconnect();
  s.start(0);
  let timer = 0;
  try {
    await Promise.race([resumed, new Promise<never>((_, reject) => {
      timer = window.setTimeout(() => reject(new Error('Audio was interrupted. Tap again to retry.')), 2000);
    })]);
    if (c.state !== 'running') throw new Error('Audio was interrupted. Tap again to retry.');
  } finally { clearTimeout(timer); }
  return c;
}

/** Resume audio on the first user gesture anywhere in the app. */
export function installUnlock(): void {
  const events = ['pointerdown', 'touchend', 'keydown'] as const;
  const handler = (): void => {
    if (!ctx || ctx.state !== 'running') void unlockAudio().catch(() => undefined);
  };
  events.forEach((e) => document.addEventListener(e, handler, true));
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && ctx && ctx.state !== 'running') void unlockAudio().catch(() => undefined);
  });
}
